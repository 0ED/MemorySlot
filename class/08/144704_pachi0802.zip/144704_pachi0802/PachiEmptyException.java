import java.lang.Exception; //エラー全般を管理

class PachiEmptyException extends Exception {
    // empty
}